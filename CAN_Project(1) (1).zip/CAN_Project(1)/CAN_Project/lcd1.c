#include<LPC21xx.h> 
#include"lcd_defines.h"
#include"lcd.h"
#include"type.h"
#include"delay.h"
void writelcd(u8 data)
{
IOPIN0=((IOPIN0&~(0XFF<<lcd_data))|(data<<lcd_data));
IOSET0=1<<lcd_en;
delay_us(1);
IOCLR0=1<<lcd_en;
delay_ms(2);
}
void cmdlcd(u8 cmd)
{
IOCLR0=1<<lcd_rs;
writelcd(cmd);
}
void charlcd(u8 ascii)
{
IOSET0=1<<lcd_rs;
writelcd(ascii);
}
void Initlcd(void)
{
IODIR0|=0xff<<lcd_data|1<<lcd_rs|1<<lcd_rw|1<<lcd_en;
delay_ms(15);
cmdlcd(0x30);
delay_ms(2);
delay_us(100);
cmdlcd(0x30);
delay_us(100);
cmdlcd(0x30);
cmdlcd(MODE_8BIT_2LINE);
cmdlcd(DSP_ON_CUR_BLK);
cmdlcd(CLEAR_LCD);
cmdlcd(SHIFT_CUR_RIGHT);
}
void strlcd(s8 *str)
{
 while(*str)
 charlcd(*str++);
}
void U32lcd(u32 num)
{
 char a[10];
 int i=0;
 if(num==0)
 {
 charlcd('0');
 }
 else
 {
 while(num>0)
 {
 a[i]=(num%10)+48;
 i++;
 num/=10;
 }
 for(--i;i>=0;i--)
 charlcd(a[i]);
 }
 }
 void S32lcd(s32 num)
 {
 if(num<0)
 {
 charlcd('-');
 num=-num;
 }
 U32lcd(num);
 }
 void F32lcd(f32 fnum,u32 ndp)
 {
 u32 num,i;
 if(fnum<0.0)
 {
 charlcd('-');
 fnum=-fnum;
 }
 num=fnum;
 U32lcd(num);
 charlcd('.');
 for(i=0;i<ndp;i++)
 {
 fnum=(fnum-num)*10;
 num=fnum;
 charlcd(num+48);
 }
 }
 void hexalcd(u32 num)
 {
 char a[8],t;
 int i=0;
 if(num==0)
 {
 charlcd('0');
 }
 else
 {
 while(num>0)
 {
 t=(num%16);
 t=(t>9)?('A'+(t-10)):(t+48);
 a[i]=t;
 i++;
 num/=16;
 }
 for(--i;i>=0;i--)
 charlcd(a[i]);
 }
 }
 void octlcd(u32 num)
 {
 char a[10];
 int i=0;
 if(num==0)
 charlcd('0');
 else
 {
 while(num>0)
 {
 a[i]=(num%8)+48;
 i++;
 num/=8;
 }
 for(--i;i>0;i--)
 charlcd (a[i]);
 }
 }
 void binlcd(u32 num,u32 nBD)
 {
 s32 i;
 for(i=(nBD-1);i>-0;i--)
 {
 charlcd(((num>i)&1)+48);
 }
 }
 void buildcgram(u8 *p,u8 nbytes)
 {
 u32 i;
 cmdlcd(GOTO_CGRAM_START);
 for(i=0;i<nbytes;i++)
 {
 charlcd(p[i]);
 }
 cmdlcd(GOTO_LINE1_POS0);		                                                                                                                                                                                                                                                                                                                                                                                                   
 }
 
 
