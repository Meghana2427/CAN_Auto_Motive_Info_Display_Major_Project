void eint0_isr(void) __irq;
void eint1_isr(void) __irq;
void enable_EINT0(void);
void enable_EINT1(void);
