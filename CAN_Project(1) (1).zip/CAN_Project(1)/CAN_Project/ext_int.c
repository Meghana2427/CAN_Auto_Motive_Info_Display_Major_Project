#include<LPC21XX.h>								  
#include"type.h"
#include"delay.h"
#include"external_interrupt.h"
#include"lcd.h"
#include"lcd_defines.h"
#include"pin_connect_block.h"
#include"can.h"
#include"can_defines.h"
#define eint1_vic_ch0 15
#define eint0_vic_ch0 14
u32 count=0,count1=0;
extern u32 flag2;
extern u32 flag1;
extern struct CAN_Frame txFrame;
void eint0_isr(void) __irq
{
flag1++;
flag2=0;
/*cmdlcd(0xd4);
U32lcd(flag1);
cmdlcd(0xd4+5);
U32lcd(flag2);*/
EXTINT=1<<0;
VICVectAddr=0;
}
void eint1_isr(void) __irq
{
flag2++;
flag1=0;
/*cmdlcd(0xd4);
U32lcd(flag1);
cmdlcd(0xd4+5);
U32lcd(flag2);	 */
EXTINT=1<<1;
VICVectAddr=0;
}

void enable_EINT0(void)
{
CfgPortPinFunc(0,16,1);
VICIntEnable|=1<<eint0_vic_ch0;
VICVectCntl0=(1<<5)|eint0_vic_ch0;
VICVectAddr0=(u32)eint0_isr;
//enable EINT0 via ext int blk
//EXTINT=0;
EXTMODE|=1<<0;
//cnf eint0 for raising edge
//EXTPOLAR=1<<0;
}

void enable_EINT1(void)
{
CfgPortPinFunc(0,14,2);
VICIntEnable|=1<<eint1_vic_ch0;
VICVectCntl1=(1<<5)|eint1_vic_ch0;
VICVectAddr1=(u32)eint1_isr;
//enable EINT1 via ext int blk
//EXTINT=0;
EXTMODE|=1<<1;
//cnf eint1 for raising edge
//EXTPOLAR=1<<1;
}

