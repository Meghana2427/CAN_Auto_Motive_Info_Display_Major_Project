#include "type.h"

void CfgPortPinFunc(u32 portNo,u32 pinNo,u32 pinF);
