#include "type.h"

#include <LPC21xx.h>

void CfgPortPinFunc(u32 portNo,u32 pinNo,u32 pinF)

{

 if(portNo==0)

 {	

   if(((s32)pinNo>=0)&&(pinNo<=15))	 

    PINSEL0=((PINSEL0&~(3<<(pinNo*2)))|

	          (pinF<<(pinNo*2))); 		

	 else if((pinNo>=16)&&(pinNo<=31))

    PINSEL1=((PINSEL1&~(3<<((pinNo-16)*2)))|

	          (pinF<<((pinNo-16)*2))); 

}
}
