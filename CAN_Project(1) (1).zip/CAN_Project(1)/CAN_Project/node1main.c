#include<LPC21XX.h>
#include"type.h"
#include"pin_connect_block.h"
#include"delay.h"
#include"lcd_defines.h"
#include"lcd.h"
#include"external_interrupt.h"
#include"ds18b20.h"
#include"can.h"
#include"can_defines.h"
#define sw1 16
#define sw2 14

//void eint0_isr(void)__irq;
u32 flag=1;
char cgram_lut[] = {0x0e,0x11,0x11,0x11,0x11,0x11,0x11,0x1f};

main()
{
u32 temp;
u8 tp,tpd;
struct CAN_Frame txFrame;
//intialize lcd
Initlcd();
Init_CAN1();
enable_EINT0();
enable_EINT1();
cmdlcd(GOTO_LINE1_POS0);
strlcd("DS18B20 Interface:");
delay_ms(2000);
cmdlcd(GOTO_LINE2_POS0);

while(1)

{
temp=ReadTemp();  //READING TEMPERATURE FROM DS18B20 USING 1-WIRE PROTOCOL

tp=temp>>4;	  //GETTING INTEGER PART
tpd=temp&0x08?0x35:0x30;//GETTING FRACTIONAL PART        
cmdlcd(GOTO_LINE2_POS0);
strlcd("Temp =");
S32lcd(tp);
charlcd('.');
charlcd(tpd);
strlcd(" C  ");
if(flag==1)
{
CAN1_Tx(txFrame); 
}
}   
}

