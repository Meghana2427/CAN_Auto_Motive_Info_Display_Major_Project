#include<LPC21XX.h>
#include"type.h"
#include"pin_connect_block.h"
#include"delay.h"
#define  eint1_vic_ch0 15
#define eint0_vic_ch0 14
//void eint0_isr(void)__irq;
u32 count;
void eint0_isr(void) __irq
{
count=0;
EXTINT=1<<0;
VICVectAddr=0;
cmdlcd(GOTO_LINE1_POS0);
strclcd("EINT0");
delay_ms(2000);
}
void eint1_isr(void) __irq
{
count=0;
EXTINT=1<<0;
VICVectAddr=0;
Ccmdlcd(GOTO_LINE2_POS0);
delay_ms(2000);
}

main()
{
Initlcd();
IODIR0|=1<<LED||1<<LED1;
CfgPortPinFunc(0,1,3);
CfgPortPinFunc(0,3,3);
VICIntEnable=1<<eint0_vic_ch0;|1<<eint1_vic_ch0 
VICVectCntl0=(1<<5)|eint0_vic_ch0;
VICVectCntl1=(1<<5)|eint1_vic_ch0;
VICVectAddr0=(u32)eint0_isr;
VICVectAddr1=(u32)eint1_isr;


EXTMODE=1<<0;
EXTMODE=1<<1;

while(1) 
  {
    count++;
   }
   
}

