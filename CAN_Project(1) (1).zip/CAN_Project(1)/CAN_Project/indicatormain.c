#include<LPC21XX.h>
#include"can.h"
#include"delay.h"
#include"can_defines.h"
#include"type.h"
#define led 0
int main()
{
u8 arr[8]={0x7f,0xbf,0xdf,0xef,0xf7,0xfb,0xfd,0xfe};
s32 i;
struct CAN_Frame rxFrame;   

Init_CAN1();
IODIR0|=0XFF<<led;
delay_s(2);
IOPIN0=0Xff<<led;   
/*while(1)   
{
if(((C1GSR&RBS_BIT_READ)==1)) {  
	CAN1_Rx(&rxFrame);
}

if(((rxFrame.ID==1)&&(rxFrame.Data1=='L')&&(rxFrame.Data2==0x00)))
{
for(i=0;i<=7;i++)
{

IOPIN0=arr[i]<<led;
delay_ms(100);
}
}
else if(((rxFrame.ID==1)&&(rxFrame.Data1=='L')&&(rxFrame.Data2==0xff)))
{
IOPIN0=0Xff<<led; 
delay_ms(200);
}
else if(((rxFrame.ID==1)&&(rxFrame.Data1=='R')&&(rxFrame.Data2==0x00)))
{
for(i=7;i>=0;i--)
{
IOPIN0=arr[i]<<led;
delay_ms(100);
}
}
else if(((rxFrame.ID==1)&&(rxFrame.Data1=='R')&&(rxFrame.Data2==0xff)))
{
IOPIN0=0Xff<<led;
delay_ms(200); 
}
} */
}


