#include<LPC21XX.h>
#include"type.h"
#include"rtc.h"
#include"pin_connect_block.h"
#include"delay.h"
#include"lcd__defines.h"
#include"lcd.h"
#include"external_interrupt.h"
#include"ds18b20.h"
#include"can.h"
#include"can_defines.h"
#define sw1 16
#define sw2 14
u32 flag1=0,flag2=0;
char cgram_lut[] = {0x0e,0x11,0x11,0x11,0x11,0x11,0x11,0x1f};
unsigned char left_arrow[8]={0x00,0x04,0x08,0x1F,0x08,0x04,0x00,0x00};
unsigned char right_arrow[8]={0x00,0x04,0x02,0x1f,0x02,0x04,0x00,0x00};
struct CAN_Frame txFrame;
struct CAN_Frame rxFrame;
u8 can_msg_available(void)
{
  return (C1GSR&RBS_BIT_READ)?1:0;  
}
u8 can_t_msg(void)
{
  return ((C1GSR&TCS1_BIT_READ)==0);
}
 
main()
{
u32 temp;
u8 tp,tpd;
s32 hour,min,sec;
Initlcd();//intialize lcd
Init_CAN1();//intialize CAN
RTC_Init();//intialize RTC

enable_EINT0();//enabling external interrupt EINT0
enable_EINT1();//enabling external interrupt EINT1

cmdlcd(GOTO_LINE1_POS0);
strlcd("DS18B20 Interface:");
delay_ms(2000);
while(1)
{

	temp=ReadTemp();//READING TEMPERATURE FROM DS18B20 USING 1-WIRE PROTOCOL
	tp=temp>>4;//GETTING INTEGER PART
	tpd=temp&0x08?0x35:0x30;//GETTING FRACTIONAL PART        
	cmdlcd(GOTO_LINE2_POS0);//Displaying temp on lcd
	strlcd("Temp=");
	cmdlcd(0xC0+5);
	S32lcd(tp);
	cmdlcd(0xC0+7);
	charlcd('.');
	cmdlcd(0xC0+8);
	charlcd(tpd);
	charlcd(223);
	cmdlcd(0xC0+9);
	strlcd("C");
	GetRTCTime(&hour,&min,&sec);
	DisplayRTCTime(hour,min,sec);//Displaying RTC time	 */
	buildcgram(left_arrow,8,0x94,0x40);
	charlcd(0);
	buildcgram(right_arrow,8,0x96,0x48);
	charlcd(1);
	if(can_t_msg())
	{
		 if(flag1==1 && flag2==0)
		 {
		   txFrame.ID=2;
		   txFrame.vbf.RTR=0;
		   txFrame.vbf.DLC=1;
		   txFrame.Data1=1;
		   CAN1_Tx(txFrame);
		   cmdlcd(0x94);
		   strlcd(" ");
		   delay_ms(200);
		   buildcgram(left_arrow,8,0x94,0x40);
		   charlcd(0);		 
		   delay_ms(200);
		 }
		else if(flag1>1)
		{
		  flag1=0;
		  txFrame.ID=2;
		  txFrame.vbf.RTR=0;
		  txFrame.vbf.DLC=1;
		  txFrame.Data1=0;
		  CAN1_Tx(txFrame);
		  buildcgram(left_arrow,8,0x94,0x40);
		  charlcd(0);
		  buildcgram(right_arrow,8,0x96,0x48);
     	  charlcd(1);
		}
		if(flag2==1 && flag1==0)
		{
		   txFrame.ID=3;
		   txFrame.vbf.RTR=0;
		   txFrame.vbf.DLC=1;
		   txFrame.Data1=1;
		   CAN1_Tx(txFrame);
		   cmdlcd(0x96);
		   strlcd(" ");
		   delay_ms(200);
		   buildcgram(right_arrow,8,0x96,0x48);
		   charlcd(1);
		   delay_ms(200);
		   
		}
		else if(flag2>1)
		{
		  flag2=0;
		  txFrame.ID=3;
		  txFrame.vbf.RTR=0;
		  txFrame.vbf.DLC=1;
		  txFrame.Data1=0;
		  CAN1_Tx(txFrame);
		  buildcgram(left_arrow,8,0x94,0x40);
		  charlcd(0);
		  buildcgram(right_arrow,8,0x96,0x48);
		  charlcd(1);
		}
	}
	if(can_msg_available())
	{
		CAN1_Rx(&rxFrame);
		if(rxFrame.ID==4)
		{
				cmdlcd(0xd4);
				strlcd("      ");
				cmdlcd(0xd4);
				U32lcd(rxFrame.Data1);
				cmdlcd(0xd4+2);
				charlcd('%');
		}
	}		
  }
}


