 #include"type.h"
void writelcd(u8 dat);
void cmdlcd(u8 cmd);
void charlcd(u8 ascii);
void Initlcd(void);
void strlcd(s8*);
void U32lcd(u32);
void S32lcd(s32);
void F32lcd(f32,u32);
void hexalcd(u32);
void octlcd(u32);
void binlcd(u32,u32);
void buildcgram(u8*,u8,int,int);
