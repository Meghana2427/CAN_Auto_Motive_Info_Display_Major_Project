    /*  -------INDICATOR NODE-------  */
#include <LPC21xx.h>   
#include"can.h"
#include "can_defines.h"
#include "delay.h"
#include "defines.h"
#include "type.h"
#include "lcd.h"
#define LEDS 10
struct CAN_Frame rxFrame;
u32 i;
u8 R_LUT[]={128,192,224,240,248,252,254,255};
volatile u8 l_s=0;
volatile u8 r_s=0;

u8 can_r_available(void)
{
  return (C1GSR&RBS_BIT_READ)?1:0;  
}
void check_can_message(void)
{
   CAN1_Rx(&rxFrame);
   if(rxFrame.ID==2)
   {
     if(rxFrame.Data1==1)
	 {
	   l_s=1;
	   r_s=0;
	 }
	  else
	  {
	    l_s=0;
	  } 
   }
   else if(rxFrame.ID==3)
   {
     if(rxFrame.Data1==1)
	 {
	   r_s=1;
	   l_s=0;
	 }
	 else
	 {
	   r_s=0;
	 }
   }
}

void Blink_leds(void)
{
        check_can_message();
       if(l_s==1 && r_s==0)
		{
			for(i=1;i<=255;i+=(i+1))
			{
			  if(l_s==0)
			  break;
			  WRITEBYTE(IOPIN0,LEDS,~i);
			  delay_ms(100);
			}
		}
	   else if(r_s==1 && l_s==0)
		{
			for(i=0;i<=7;i++)
			{
			  if(r_s==0)
			  break;
			  WRITEBYTE(IOPIN0,LEDS,~(R_LUT[i]));
			  delay_ms(100);
			 }
		}
		else
		{
		  IOSET0=0XFF<<LEDS;
		  //delay_ms(100);
		}
		//delay_ms(100);
}

int main()   
{   
	IODIR0|=0XFF<<LEDS;
	IOSET0=0XFF<<LEDS;
	Initlcd();
    Init_CAN1();
	strlcd("indicator:");
		while(1)
		{
		  //if(can_r_available())
		    check_can_message();
	if(rxFrame.ID==2)
   	{
	cmdlcd(0xc0);
     U32lcd(l_s);
     U32lcd(r_s);

	 }
	  if(rxFrame.ID==3)
   {
    cmdlcd(0x94);
    U32lcd(l_s);
	U32lcd(r_s);

	  }

		     Blink_leds();
		    //delay_ms(100);
	}
}	      
