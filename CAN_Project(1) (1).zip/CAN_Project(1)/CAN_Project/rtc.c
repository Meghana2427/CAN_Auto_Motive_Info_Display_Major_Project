#include <LPC21xx.h>

#include "type.h"

#include "lcd.h"

#include "lcd_defines.h"

#include "delay.h"


//include LCD header files


// System clock and peripheral clock Macros

#define FOSC	12000000 

#define CCLK  (5*FOSC)   	

#define PCLK  (CCLK/4)


// RTC Macros

#define PREINT_VAL	 (int)((PCLK / 32768) - 1) 

#define PREFRAC_VAL  (PCLK -((PREINT + 1) * 32768))

#define RTC_ENABLE	  (1<<0)  

#define RTC_RESET     (1<<1) 

#define RTC_CLKSRC_EX (1<<4)





s32 hour,min,sec,date,month,year,day;


char week[][4] = {"SUN","MON","TUE","WED","THU","FRI","SAT"};

// RTC Initialization: Configures and enables the RTC

void RTC_Init(void) 

{

    // Disable & Reset the RTC

		CCR = RTC_RESET;

	

	

    // Set prescaler integer part

		PREINT = PREINT_VAL;	

    // Set prescaler fractional part

		PREFRAC = PREFRAC_VAL;


    // Enable the RTC

		//CCR = RTC_ENABLE;	//for LPC2129

		CCR = RTC_ENABLE | RTC_CLKSRC_EX;	//For LPC2148

	

}


void GetRTCTime(s32 *hour,s32 *min,s32 *sec)

{

	*hour = HOUR;

	*min = MIN;

	*sec = SEC;	

}


void DisplayRTCTime(u32 hour,u32 min,u32 sec)

{
    cmdlcd(GOTO_LINE2_POS0+11);

	charlcd((hour/10)+48);
	cmdlcd(GOTO_LINE2_POS0+12);
	charlcd((hour%10)+48);
	cmdlcd(GOTO_LINE2_POS0+13);	
	charlcd(':');
	cmdlcd(GOTO_LINE2_POS0+14);
	charlcd((min/10)+48);
	cmdlcd(GOTO_LINE2_POS0+15);
	charlcd((min%10)+48);
	cmdlcd(GOTO_LINE2_POS0+16);
	charlcd(':');
	cmdlcd(GOTO_LINE2_POS0+17);
	charlcd((sec/10)+48);
	cmdlcd(GOTO_LINE2_POS0+18);
	charlcd((sec%10)+48);

}


void SetRTCTime(u32 hr,u32 mi,u32 se)

{

	HOUR = hr;

	MIN = mi;

	SEC = se;	

}


void GetRTCDate(s32 *date,s32 *month,s32 *year)

{

	*date = DOM;

	*month = MONTH;

	*year = YEAR;	

}
void DisplayRTCDate(u32 date,u32 month,u32 year)

{

	cmdlcd(GOTO_LINE2_POS0);
     charlcd((date/10)+48);

	charlcd((date%10)+48);

	charlcd('/');

	charlcd((month/10)+48);

	charlcd((month%10)+48);

	charlcd('/');

	U32lcd(year);

}


void SetRTCDate(u32 date,u32 month,u32 year)

{

	DOM = date;

	MONTH = month;

	YEAR = year;	

}


void GetRTCDay(s32 *day)

{

	*day = DOW;

}


void DisplayRTCDay(u32 day)

{

	cmdlcd(GOTO_LINE1_POS0+10);

	strlcd(week[day]);	

}


void SetRTCDay(u32 day)
{
	DOW = day;

}


