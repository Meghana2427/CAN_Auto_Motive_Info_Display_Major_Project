#include<LPC21XX.h>
#include"can.h"
#include"delay.h"
#include"can_defines.h"
#include"type.h"
#define WRITEBYTE(WORD,BP,BYTE)  (WORD=(WORD&~(255<<BP))|(BYTE<<BP))
#define LEDS 0

u32 i;
u8 R_LUT[]={128,192,224,240,248,252,254,255};
volatile u8 l_s=0;
volatile u8 r_s=0;

u8 can_r_available(void)
{
  return (C1GSR&RBS_BIT_READ)?1:0;  
}
void check_can_message(void)
{
   struct CAN_Frame rxFrame;
   CAN1_Rx(&rxFrame);
   if(rxFrame.ID==2)
   {
     if(rxFrame.Data1==1)
	 {
	   l_s=1;
	   r_s=0;
	 }
	  else
	  {
	    l_s=0;
	  } 
   }
   else if(rxFrame.ID==3)
   {
     if(rxFrame.Data1==1)
	 {
	   r_s=1;
	   l_s=0;
	 }
	 else
	 {
	   r_s=0;
	 }
   }
}

void Blink_leds(void)
{
        check_can_message();
       if(l_s==1 && r_s==0)
		{
			for(i=1;i<=255;i+=(i+1))
			{
			  if(l_s==0)
			  break;
			  WRITEBYTE(IOPIN0,LEDS,~i);
			  delay_ms(100);
			}
		}
	   else if(r_s==1 && l_s==0)
		{
			for(i=0;i<=7;i++)
			{
			  if(r_s==0)
			  break;
			  WRITEBYTE(IOPIN0,LEDS,~(R_LUT[i]));
			  delay_ms(100);
			 }
		}
		else
		{
		  IOSET0=0XFF<<LEDS;
		  //delay_ms(100);
		}
		//delay_ms(100);
}

int main()   
{   
	IODIR0|=0XFF<<LEDS;
	IOSET0=0XFF<<LEDS;
    Init_CAN1();
		while(1)
		{
		    check_can_message();
		     Blink_leds();
		}
}	      
