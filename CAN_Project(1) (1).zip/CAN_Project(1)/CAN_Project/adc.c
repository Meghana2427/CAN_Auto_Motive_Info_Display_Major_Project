#include <LPC21xx.h>
#include"type.h"
#include"defines.h"
#include"adc_defines.h"
#include"delay.h"


void Init_ADC(void)

{
PINSEL1=0x01000000;
  ADCR=PDN_BIT|CLKDIV;	

}


f32 Read_ADC(u8 chNo)

{

  u16 adcVal=0;

	f32 eAR;

	ADCR&=0XFFFFFF00;
	//WRITEBYTE(ADCR,0,chNo);
	 ADCR|=1<<chNo;
	//SETBIT(ADCR,ADC_START_BIT);
	 ADCR|=1<<ADC_START_BIT;
	delay_us(3);

	while(((ADDR>>DONE_BIT)&1)==0);

	//CLRBIT(ADCR,ADC_START_BIT);
	 ADCR&=~(1<<ADC_START_BIT);
	adcVal=(ADDR>>6)&0x3FF;

	eAR=((adcVal*3.3)/1023);

	return eAR;

}
